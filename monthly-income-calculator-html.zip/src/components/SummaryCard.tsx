import { formatRupiah } from "../utils/format";

interface SummaryCardProps {
  monthLabel: string;
  totalIncome: number;
  totalExpense: number;
  netIncome: number;
  onSave: () => void;
  saved: boolean;
}

export default function SummaryCard({
  monthLabel,
  totalIncome,
  totalExpense,
  netIncome,
  onSave,
  saved,
}: SummaryCardProps) {
  const isPositive = netIncome >= 0;
  const savingsRate = totalIncome > 0 ? Math.round((netIncome / totalIncome) * 100) : 0;

  return (
    <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-600 via-indigo-600 to-violet-700 p-6 text-white shadow-lg shadow-indigo-200 sm:p-8">
      <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium uppercase tracking-wide text-indigo-100">Ringkasan • {monthLabel}</p>
          <p className="mt-2 text-4xl font-bold tracking-tight sm:text-5xl">{formatRupiah(netIncome)}</p>
          <p className="mt-1 text-sm text-indigo-100">
            {isPositive ? "Pendapatan bersih bulan ini" : "Defisit bulan ini"}
          </p>
        </div>
        <button
          onClick={onSave}
          className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-white/15 px-5 py-3 text-sm font-semibold text-white ring-1 ring-white/30 backdrop-blur transition hover:bg-white/25"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z" strokeLinejoin="round" />
            <path d="M17 21v-8H7v8" strokeLinejoin="round" />
            <path d="M7 3v5h8" strokeLinejoin="round" />
          </svg>
          {saved ? "Tersimpan!" : "Simpan Bulan Ini"}
        </button>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="rounded-xl bg-white/10 p-4">
          <p className="text-xs font-medium uppercase tracking-wide text-indigo-100">Total Pemasukan</p>
          <p className="mt-1 text-lg font-bold">{formatRupiah(totalIncome)}</p>
        </div>
        <div className="rounded-xl bg-white/10 p-4">
          <p className="text-xs font-medium uppercase tracking-wide text-indigo-100">Total Pengeluaran</p>
          <p className="mt-1 text-lg font-bold">{formatRupiah(totalExpense)}</p>
        </div>
        <div className="rounded-xl bg-white/10 p-4">
          <p className="text-xs font-medium uppercase tracking-wide text-indigo-100">Rasio Tabungan</p>
          <p className="mt-1 text-lg font-bold">{savingsRate}%</p>
        </div>
      </div>
    </div>
  );
}

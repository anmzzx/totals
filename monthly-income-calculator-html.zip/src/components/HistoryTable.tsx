import type { MonthRecord } from "../types";
import { formatRupiah } from "../utils/format";

interface HistoryTableProps {
  records: MonthRecord[];
  onDelete: (id: string) => void;
}

export default function HistoryTable({ records, onDelete }: HistoryTableProps) {
  if (records.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-8 text-center text-sm text-slate-400">
        Riwayat bulanan akan muncul di sini setelah kamu menyimpan data.
      </div>
    );
  }

  const sorted = [...records].sort((a, b) => b.monthKey.localeCompare(a.monthKey));

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[560px] text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Bulan</th>
              <th className="px-4 py-3 font-medium">Pemasukan</th>
              <th className="px-4 py-3 font-medium">Pengeluaran</th>
              <th className="px-4 py-3 font-medium">Bersih</th>
              <th className="px-4 py-3 font-medium"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sorted.map((record) => (
              <tr key={record.id} className="transition hover:bg-slate-50">
                <td className="px-4 py-3 font-medium capitalize text-slate-800">{record.monthLabel}</td>
                <td className="px-4 py-3 text-emerald-700">{formatRupiah(record.totalIncome)}</td>
                <td className="px-4 py-3 text-rose-700">{formatRupiah(record.totalExpense)}</td>
                <td
                  className={`px-4 py-3 font-semibold ${
                    record.netIncome >= 0 ? "text-indigo-700" : "text-red-600"
                  }`}
                >
                  {formatRupiah(record.netIncome)}
                </td>
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => onDelete(record.id)}
                    className="rounded-md p-1.5 text-slate-400 transition hover:bg-red-50 hover:text-red-500"
                    aria-label="Hapus riwayat"
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                      <path d="M3 6h18" strokeLinecap="round" />
                      <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" strokeLinecap="round" />
                      <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" strokeLinecap="round" />
                    </svg>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

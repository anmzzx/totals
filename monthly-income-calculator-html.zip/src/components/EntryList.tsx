import { useState } from "react";
import type { EntryItem } from "../types";
import { formatRupiah, parseNumberInput } from "../utils/format";

interface EntryListProps {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  accent: "emerald" | "rose";
  items: EntryItem[];
  onAdd: (name: string, amount: number) => void;
  onRemove: (id: string) => void;
  placeholder: string;
}

const accentClasses: Record<
  "emerald" | "rose",
  { border: string; bg: string; text: string; button: string; ring: string }
> = {
  emerald: {
    border: "border-emerald-100",
    bg: "bg-emerald-50",
    text: "text-emerald-700",
    button: "bg-emerald-600 hover:bg-emerald-700",
    ring: "focus:ring-emerald-500",
  },
  rose: {
    border: "border-rose-100",
    bg: "bg-rose-50",
    text: "text-rose-700",
    button: "bg-rose-600 hover:bg-rose-700",
    ring: "focus:ring-rose-500",
  },
};

export default function EntryList({
  title,
  subtitle,
  icon,
  accent,
  items,
  onAdd,
  onRemove,
  placeholder,
}: EntryListProps) {
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const classes = accentClasses[accent];

  const total = items.reduce((sum, item) => sum + item.amount, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = parseNumberInput(amount);
    if (!name.trim() || numericAmount <= 0) return;
    onAdd(name.trim(), numericAmount);
    setName("");
    setAmount("");
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
      <div className="mb-4 flex items-center gap-3">
        <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${classes.bg} ${classes.text}`}>
          {icon}
        </div>
        <div>
          <h2 className="text-base font-semibold text-slate-900">{title}</h2>
          <p className="text-xs text-slate-500">{subtitle}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mb-4 flex flex-col gap-2 sm:flex-row">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={placeholder}
          className={`w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-800 outline-none transition focus:ring-2 ${classes.ring} sm:flex-1`}
        />
        <input
          type="text"
          inputMode="numeric"
          value={amount}
          onChange={(e) => setAmount(e.target.value.replace(/[^0-9]/g, ""))}
          placeholder="Jumlah (Rp)"
          className={`w-full rounded-lg border border-slate-200 px-3 py-2 text-sm text-slate-800 outline-none transition focus:ring-2 ${classes.ring} sm:w-40`}
        />
        <button
          type="submit"
          className={`shrink-0 rounded-lg px-4 py-2 text-sm font-medium text-white transition ${classes.button}`}
        >
          Tambah
        </button>
      </form>

      {items.length === 0 ? (
        <p className="rounded-lg border border-dashed border-slate-200 py-6 text-center text-sm text-slate-400">
          Belum ada data. Tambahkan di atas.
        </p>
      ) : (
        <ul className="mb-3 max-h-56 space-y-2 overflow-y-auto pr-1">
          {items.map((item) => (
            <li
              key={item.id}
              className="flex items-center justify-between rounded-lg border border-slate-100 bg-slate-50 px-3 py-2"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-slate-800">{item.name}</p>
                <p className="text-xs text-slate-500">{formatRupiah(item.amount)}</p>
              </div>
              <button
                onClick={() => onRemove(item.id)}
                className="ml-3 shrink-0 rounded-md p-1.5 text-slate-400 transition hover:bg-red-50 hover:text-red-500"
                aria-label={`Hapus ${item.name}`}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                  <path d="M3 6h18" strokeLinecap="round" />
                  <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" strokeLinecap="round" />
                  <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" strokeLinecap="round" />
                </svg>
              </button>
            </li>
          ))}
        </ul>
      )}

      <div className={`flex items-center justify-between rounded-lg border ${classes.border} ${classes.bg} px-3 py-2`}>
        <span className={`text-xs font-medium uppercase tracking-wide ${classes.text}`}>Subtotal</span>
        <span className={`text-sm font-bold ${classes.text}`}>{formatRupiah(total)}</span>
      </div>
    </div>
  );
}

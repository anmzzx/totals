export interface EntryItem {
  id: string;
  name: string;
  amount: number;
}

export interface MonthRecord {
  id: string;
  monthLabel: string;
  monthKey: string;
  totalIncome: number;
  totalExpense: number;
  netIncome: number;
  savedAt: string;
}

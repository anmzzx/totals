import { useEffect, useMemo, useState } from "react";
import EntryList from "./components/EntryList";
import SummaryCard from "./components/SummaryCard";
import HistoryTable from "./components/HistoryTable";
import type { EntryItem, MonthRecord } from "./types";
import { getMonthKey, getMonthLabel } from "./utils/format";

const STORAGE_KEY_PREFIX = "pendapatan-bulanan:";
const HISTORY_KEY = "pendapatan-bulanan:history";

function loadEntries(key: string): EntryItem[] {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as EntryItem[]) : [];
  } catch {
    return [];
  }
}

function loadHistory(): MonthRecord[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? (JSON.parse(raw) as MonthRecord[]) : [];
  } catch {
    return [];
  }
}

export default function App() {
  const [monthKey, setMonthKey] = useState(() => getMonthKey(new Date()));
  const [incomeItems, setIncomeItems] = useState<EntryItem[]>([]);
  const [expenseItems, setExpenseItems] = useState<EntryItem[]>([]);
  const [history, setHistory] = useState<MonthRecord[]>(() => loadHistory());
  const [justSaved, setJustSaved] = useState(false);

  useEffect(() => {
    setIncomeItems(loadEntries(`${STORAGE_KEY_PREFIX}${monthKey}:income`));
    setExpenseItems(loadEntries(`${STORAGE_KEY_PREFIX}${monthKey}:expense`));
    setJustSaved(false);
  }, [monthKey]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}${monthKey}:income`, JSON.stringify(incomeItems));
  }, [incomeItems, monthKey]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}${monthKey}:expense`, JSON.stringify(expenseItems));
  }, [expenseItems, monthKey]);

  useEffect(() => {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  }, [history]);

  const totalIncome = useMemo(() => incomeItems.reduce((sum, item) => sum + item.amount, 0), [incomeItems]);
  const totalExpense = useMemo(() => expenseItems.reduce((sum, item) => sum + item.amount, 0), [expenseItems]);
  const netIncome = totalIncome - totalExpense;
  const monthLabel = getMonthLabel(monthKey);

  const addIncome = (name: string, amount: number) => {
    setIncomeItems((prev) => [...prev, { id: crypto.randomUUID(), name, amount }]);
  };
  const removeIncome = (id: string) => setIncomeItems((prev) => prev.filter((item) => item.id !== id));

  const addExpense = (name: string, amount: number) => {
    setExpenseItems((prev) => [...prev, { id: crypto.randomUUID(), name, amount }]);
  };
  const removeExpense = (id: string) => setExpenseItems((prev) => prev.filter((item) => item.id !== id));

  const handleSaveMonth = () => {
    const record: MonthRecord = {
      id: monthKey,
      monthKey,
      monthLabel,
      totalIncome,
      totalExpense,
      netIncome,
      savedAt: new Date().toISOString(),
    };
    setHistory((prev) => {
      const withoutCurrent = prev.filter((r) => r.monthKey !== monthKey);
      return [...withoutCurrent, record];
    });
    setJustSaved(true);
    setTimeout(() => setJustSaved(false), 2000);
  };

  const handleDeleteHistory = (id: string) => {
    setHistory((prev) => prev.filter((r) => r.id !== id));
  };

  const handleMonthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const [year, month] = e.target.value.split("-").map(Number);
    if (!year || !month) return;
    setMonthKey(`${year}-${String(month).padStart(2, "0")}`);
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-16">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl flex-col gap-4 px-4 py-6 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow-md shadow-indigo-200">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M12 1v22" strokeLinecap="round" />
                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" strokeLinecap="round" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 sm:text-xl">Kalkulator Pendapatan Bulanan</h1>
              <p className="text-xs text-slate-500 sm:text-sm">Hitung total pemasukan, pengeluaran, dan sisa bersih tiap bulan.</p>
            </div>
          </div>
          <label className="flex items-center gap-2 self-start rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm sm:self-auto">
            <span className="text-slate-500">Bulan</span>
            <input
              type="month"
              value={monthKey}
              onChange={handleMonthChange}
              className="bg-transparent font-medium text-slate-800 outline-none"
            />
          </label>
        </div>
      </header>

      <main className="mx-auto mt-8 max-w-5xl space-y-8 px-4 sm:px-6">
        <SummaryCard
          monthLabel={monthLabel}
          totalIncome={totalIncome}
          totalExpense={totalExpense}
          netIncome={netIncome}
          onSave={handleSaveMonth}
          saved={justSaved}
        />

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <EntryList
            title="Sumber Pemasukan"
            subtitle="Gaji, bonus, usaha sampingan, dll"
            accent="emerald"
            placeholder="Contoh: Gaji Pokok"
            items={incomeItems}
            onAdd={addIncome}
            onRemove={removeIncome}
            icon={
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M12 19V5" strokeLinecap="round" />
                <path d="M5 12l7-7 7 7" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            }
          />
          <EntryList
            title="Pengeluaran"
            subtitle="Sewa, tagihan, cicilan, kebutuhan harian"
            accent="rose"
            placeholder="Contoh: Sewa Kos"
            items={expenseItems}
            onAdd={addExpense}
            onRemove={removeExpense}
            icon={
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                <path d="M12 5v14" strokeLinecap="round" />
                <path d="M19 12l-7 7-7-7" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            }
          />
        </div>

        <section>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-semibold text-slate-900">Riwayat Bulanan</h2>
            <span className="text-xs text-slate-400">{history.length} bulan tersimpan</span>
          </div>
          <HistoryTable records={history} onDelete={handleDeleteHistory} />
        </section>
      </main>

      <footer className="mx-auto mt-12 max-w-5xl px-4 text-center text-xs text-slate-400 sm:px-6">
        Data disimpan otomatis di browser kamu (localStorage), tidak dikirim ke server manapun.
      </footer>
    </div>
  );
}
